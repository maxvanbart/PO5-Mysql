<?php
//including the database connection file
include_once("includes/db_connect.php");
include_once 'includes/functions.php';
sec_session_start();
$result1 = mysqli_query($mysqli, "SELECT * FROM leeftijdscategorie");
$result2 = mysqli_query($mysqli, "SELECT * FROM waarschuwing");
$result3 = mysqli_query($mysqli, "SELECT * FROM acteur");
$result4 = mysqli_query($mysqli, "SELECT * FROM regisseur");
$result5 = mysqli_query($mysqli, "SELECT * FROM genre");
?>

<html>
<head>
    <title>Add Data</title>
	<link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
 
<body>
<?php if (login_check($mysqli) == true) : ?>
    <a href="gegevens.php">Home</a>
    <br/><br/>
 	
	
 
 
 
<!-- <?php
foreach ($_POST['flower'] as $names)
{
        print "You are selected $names<br/>";
}

?> -->
 
 

 
 
    <form id="gegevens" action="addfilm3.php" method="post" name="form1" enctype="multipart/form-data">
        <table id="gegevens">
            <tr> 
                <td>Titel</td>
                <td><input type="text" name="titel" enctype="multipart/form-data"></td>
            </tr>
            <tr>
	            <td>
	            	Acteurs
		            <select name="acteur[]" multiple="multiple" style="height:400px;" form="gegevens">
						<?php
							while($res3 = mysqli_fetch_array($result3)) {
								echo "<option value='".$res3['acteurnummer']."'>".$res3['acteurvoornaam']." ".$res3['acteurachternaam']."</option>";
							};
						?>
					</select>
				</td>
            </tr>
            <tr>
	            <td>
		            Regisseur
		            <select name="regisseur" form="gegevens">
						<?php
							while($res4 = mysqli_fetch_array($result4)) {
								echo "<option value='".$res4['regisseurnummer']."'>".$res4['regisseurvoornaam']." ".$res4['regisseurachternaam']."</option>";
							};
						?>
					</select>
				</td>
            </tr>
			<tr>
				<td>Leeftijdscategorie</td>
				<td><input name="leeftijdscategorienummer" type="radio" value="1">Alle leeftijden</td>
				<td><input name="leeftijdscategorienummer" type="radio" value="2">Vanaf 6 jaar</td>
				<td><input name="leeftijdscategorienummer" type="radio" value="3">Vanaf 9 jaar</td>
				<td><input name="leeftijdscategorienummer" type="radio" value="4">Vanaf 12 jaar</td>
				<td><input name="leeftijdscategorienummer" type="radio" value="5">Vanaf 16 jaar</td>
			</tr>
			<tr>
				<td>Waarschuwing</td>
				<input type="hidden" name="geweld" value=0>
				<td><input type="checkbox" name="geweld" value=1>Geweld<br></td>
				
				
				
				<input type="hidden" name="angst" value=0>
				<td><input type="checkbox" name="angst" value=1>Angst<br></td>
				
				<input type="hidden" name="seks" value=0>
				<td><input type="checkbox" name="seks" value=1>Seks<br></td>
				
				<input type="hidden" name="grof" value=0>
				<td><input type="checkbox" name="grof" value=1>Grof<br></td>
				<input type="hidden" name="dralc" value=0>
				<td><input type="checkbox" name="dralc" value=1>Drugs- en/of alcoholgebruik<br></td>
				<input type="hidden" name="discr" value=0>
				<td><input type="checkbox" name="discr" value=1>Discriminatie<br></td>
				
            </tr>
<!--              <tr> 
                <td>Genre</td>
                <td><input type="text" name="genrenaam"></td>
            </tr>-->
            <tr>
	            <td>
		            Genre
		            <select name="genre" form="gegevens">
						<?php
							while($res5 = mysqli_fetch_array($result5)) {
								echo "<option value='".$res5['genrenummer']."'>".$res5['genrenaam']."</option>";
							};
						?>
					</select>
				</td>
            </tr>
            <tr> 
                <td>imdblink</td>
                <td><input type="text" name="imdblink"></td>
            </tr>
		  	<tr>
				  <td><input type="file" name="image" enctype="multipart/form-data"></td>
		  	</tr>
            <tr> 
                <td></td>
                <td><input type="submit" name="Submit" value="Add"></td>
            </tr>
        </table>
    </form>
<!--
	<table id="leeftijd">
	<tbody>
        <?php 
        //while($res = mysql_fetch_array($result)) { // mysql_fetch_array is deprecated, we need to use mysqli_fetch_array 
        while($res1 = mysqli_fetch_array($result1)) {         
            echo "<td>";?> <img src="<?php echo $res1['afbeelding']; ?>"> <?php "</td>";
            echo "<td>".$res1['leeftijdscategorie']."</td>";          
        }
        ?>
	</tbody>
    </table>
	<table id="waarschuwing">
	<tbody>
        <?php  
        while($res2 = mysqli_fetch_array($result2)) {         
			echo "<td>";?> <img src="<?php echo $res2['afbeelding']; ?>"> <?php "</td>";
            echo "<td>".$res2['waarschuwing']."</td>";       
        }
        ?>
	</tbody>
    </table>
-->	
<?php else : ?>
     <p>
         <span class="error">You are not authorized to access this page.</span> Please <a href="index.php">login</a>.
     </p>
<?php endif; ?>	
</body>
</html>
