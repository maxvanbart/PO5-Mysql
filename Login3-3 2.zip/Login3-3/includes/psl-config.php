<?php

$databaseHost = 'localhost';
$databaseName = 'Filmotheek';
$databaseUsername = 'root';
$databasePassword = 'root';           

define("CAN_REGISTER", "any");
define("DEFAULT_ROLE", "member");

define("SECURE", FALSE);    

