<?php
//including the database connection file
include_once("includes/db_connect.php");
include_once 'includes/functions.php';
 
sec_session_start();

$username = $_SESSION['username'];
//fetching data in descending order (lastest entry first)
//$result = mysql_query("SELECT * FROM users ORDER BY id DESC"); // mysql_query is deprecated
$result1 = mysqli_query($mysqli, "SELECT * FROM film ORDER BY id DESC");
$result2 = mysqli_query($mysqli, "SELECT * FROM acteur");
$result3 = mysqli_query($mysqli, "SELECT * FROM regisseur");
$result4 = mysqli_query($mysqli, "SELECT * FROM genre");
$result5 = mysqli_query($mysqli, "SELECT premission_number FROM members WHERE username='$username'");
$row3 = mysqli_fetch_assoc($result5);
$row10 = implode(" ",$row3);
?>
 
<html>
<head>    
    <title>Film</title>
    <link rel="stylesheet" type="text/css" href="css/main.css" />
</head>
 
<body>
<?php if (login_check($mysqli) == true) : ?>
	<?php include "includes/menu.php" ?>
	
	<div id="main_body">
	
	
		<tbody>
		

			
		
	        <?php 
				 $ln = $_POST['leeftijdscategorienummer'];
				/* $genren = $_POST['genrenaam']; */
		        //while($res = mysql_fetch_array($result)) { // mysql_fetch_array is deprecated, we need to use mysqli_fetch_array 
		        while($res1 = mysqli_fetch_array($result1)) { 
					if ($res1['leeftijdscategorienummer'] <= $ln /* && $res1['genrenaam'] == $genren */) {
						echo "<tr>";
						echo "<table>";
								echo "<tr bgcolor='#CCCCCC'>";
								echo "<td>Cover</td>";
								echo "<td>Titel</td>";
								echo "<td>leeftijdscategorie</td>";
								echo "<td>imdblink</td>";
							/*	echo "<td>acteurvoornaam</td>";
								echo "<td>acteurachternaam</td>";
								//echo "<td>acteurnummer</td>";
								echo "<td>regisseurvoornaam</td>";
								echo "<td>regisseurachternaam</td>"; */
								echo "<td>Genre</td>";
								echo "</tr>";
						if ($res1['image'] == null){
							echo "<td><img id='cover' src='Image/404error.jpg' ></td>";
						} else {
							echo "<td><img id='cover' src='covers/".$res1['image']."' ></td>";
						}
						echo "<td>".$res1['titel']."</td>";
						echo "<td><img src=";
						switch ($res1['leeftijdscategorienummer']) {
							case 1:
								echo "leeftijd/image1.png";
								break;
							case 2:
								echo "leeftijd/image2.png";
								break;
							case 3:
								echo "leeftijd/image3.png";
								break;
							case 4:
								echo "leeftijd/image4.png";
								break;
							case 5:
								echo "leeftijd/image5.png";
								break;
							}
						echo " style='width:75px;height:75px;'></td>";
						echo "<td>"."<a href='".$res1['imdblink']."'>".'IMDB Link'."</a></td>";
						
					}
		        }
	        ?>
		</tbody>
	</table>
	
	<br></br>
	
	
	
        	?>
		</tbody>
	</table>
	
	<br></br>

	
        	?>
		</tbody>
	</table>
	
	<br></br>

	
	        ?>
		</tbody>
    </table>
    </div>
<?php else : ?>
    <p>
      <span class="error">You are not authorized to access this page.</span> Please <a href="index.php">login</a>.
    </p>
<?php endif; ?>
</body>
</html>