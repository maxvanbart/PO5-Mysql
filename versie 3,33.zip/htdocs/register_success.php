<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Secure Login: Registration Success</title>
        <link rel="stylesheet" href="css/login_screen.css" />
    </head>
    <body>
        <div id="center_login" style="height: 30%;">
        	<table style="width:100%; height:80%">
        		<tr>
        			<th>
        				<h1>Registration successful!</h1>
        			</th>
        		</tr>
        		<tr>
        			<th>
        				<p>You can now go back to the <a href="index.php">login page</a> and log in</p>
        			</th>
        		</tr>
        	</table>	
        </div>
    </body>
</html>