<?php
include_once("includes/db_connect.php");
include_once 'includes/functions.php';
sec_session_start();

?>

<html>
<head>
    <title>Add Data</title>
    <link rel="stylesheet" href="css/login_screen.css" />
</head>
 
<body>
<?php if (login_check($mysqli) == true) : ?>
<div id='center_login' style="height: 25%;">
<?php
 
	error_reporting(E_ERROR | E_PARSE);
 
if(isset($_POST['Submit'])) {    
    $acteur = $_POST['acteur'];
    $regisseur = $_POST['regisseur'];
	$titel = $_POST['titel'];
    $ln = $_POST['leeftijdscategorienummer'];
	$link = $_POST['imdblink'];
	$image = $_FILES['image']['name'];
	$genre = $_POST['genre'];
	$geweld = $_POST['geweld'];
	$angst = $_POST['angst'];
	$seks = $_POST['seks'];
	$grof = $_POST['grof'];
	$dralc = $_POST['dralc'];
	$discr = $_POST['discr'];
	$foutl = 0;
	if ($ln < 5){
		if($seks == 1){
			echo"<font color='red'>Lekker neuken mag alleen voorkomen in films vanaf 16 jaar.</font><br/>";
			$foutl = 1;
		}
		if ($dralc == 1){
			echo"<font color='red'>Het gebruik van bier en andere lekker dingen mag alleen voorkomen in films vanaf 16 jaar.</font><br/>";
			$foutl = 1;
		}
	}
	
	if ($ln < 4){
		if ($grof == 1){
			echo"<font color='red'>Deadpool mag alleen voorkomen in films vanaf 12 jaar.</font><br/>";
			$foutl = 1;
		}
		if ($discr == 1){
			echo"<font color='red'>De witte superieuriteit mag alleen benadrukt worden in films vanaf 12 jaar.</font><br/>";
			$foutl = 1;
		}
	}
	
	if ($ln < 2){
		if ($angst == 1){
			echo"<font color='red'>Enge Spoken mogen alleen voorkomen in films vanaf 6.</font><br/>";
			$foutl = 1;
		}
		if ($geweld == 1){
			echo"<font color='red'>Dingen mogen alleen kapot geslagen worden in films vanaf 6.</font><br/>";
			$foutl = 1;
		}
	}
	
	if(empty($titel) || empty($ln) || empty($link) || empty($genre) || $foutl ==1) {
		if(empty($titel)) {
			echo "<font color='red'>Titel field is empty.</font><br/>";
		}
		if(empty($acteur)) {
			echo "<font color='red'>Actor field is empty.</font><br/>";
		}
		
		if(empty($ln)) {
			echo "<font color='red'>Leeftijdscategorienummer field is empty.</font><br/>";
		}
		if(empty($genre)) {
			echo "<font color='red'>Genre field is empty.</font><br/>";
		}
		if(empty($link)) {
			echo "<font color='red'>imdblink field is empty.</font><br/>";
		}
		
		//link to the previous page
		echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
	} else {
		
		$controlle=mysqli_query($mysqli,"select * from film where titel='$titel'");
		$controllerows=mysqli_num_rows($controlle);
		
		if($controllerows>0) {
			echo "<font color='red'>Deze film bestaat al!</font><br/>";
		} elseif ($_FILES["image"]["size"] > 2000000){ 
			echo "<font color='red'>De afbeelding is meer dan 2 MB!</font><br/>";
		} else {
			$image = $_FILES['image']['name'];
			// image file directory
			$imageFileType = strtolower(pathinfo($image,PATHINFO_EXTENSION));
			$filenamenew = $titel.".".$imageFileType;
			
			if (empty($imageFileType)){
				$filenamenew = null;
			}
			
			$target = "covers/".$filenamenew;
			move_uploaded_file($_FILES['image']['tmp_name'], $target);
			
			
			
			$a = mysqli_query($mysqli, "INSERT IGNORE INTO film(titel,leeftijdscategorienummer,imdblink,image) VALUES('$titel','$ln','$link','$filenamenew')");
			$idfilm = $mysqli->insert_id;
			
			$bb = mysqli_query($mysqli,"INSERT INTO filmwaarschuwing(filmnummer,geweld,angst,seks,grof,dralc,discr) VALUES('$idfilm','$geweld','$angst','$seks','$grof','$dralc','$discr')");
			
			
			foreach($acteur as $result) {
				$cc = mysqli_query($mysqli,"INSERT INTO filmacteur(filmnummer,acteurnummer) VALUES('$idfilm','$result')");
			}
			
			$dd = mysqli_query($mysqli,"INSERT INTO filmregisseur(filmnummer,regisseurnummer) VALUES('$idfilm','$regisseur')");
			
			$ee = mysqli_query($mysqli,"INSERT INTO filmgenre(filmnummer,genrenummer) VALUES('$idfilm','$genre')");
			
			echo "<font color='green'>".$titel." is succesvol toegevoegd als film.";
		}
	}
	echo "<br/><br><a href='gegevens.php'>View Result</a>";
}
?>
</div>
<?php else : ?>
     <p>
         <span class="error">You are not authorized to access this page.</span> Please <a href="index.php">login</a>.
     </p>
<?php endif; ?>
</body>
</html>