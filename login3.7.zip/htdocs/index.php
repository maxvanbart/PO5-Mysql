<?php
include_once 'includes/db_connect.php';
include_once 'includes/functions.php';
 
sec_session_start();
 
if (login_check($mysqli) == true) {
    $logged = 'in';
} else {
    $logged = 'out';
}
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Secure Login: Log In</title>
        <link rel="stylesheet" href="css/login_screen.css" />
        <script type="text/JavaScript" src="js/sha512.js"></script> 
        <script type="text/JavaScript" src="js/forms.js"></script> 
    </head>
    <body>
        <?php
	        if (isset($_GET['error'])) {
    	        echo '<p class="error">Error Logging In!</p>';
        	}
        ?> 
        <div id='center_login' style="height: 33%;">
        	<table style="width:100%">
        		<tr>
        			<th>
        				<h2>Please Sign in</h2><br>
        			</th>
        		</tr>
        		<tr>
		        	<form action="includes/process_login.php" method="post" name="login_form">                      
		            	<th>
		            		<table>
		            			<tr>	
		            				<th style="width:26%">
		            				</th>
		            				<th style="width:12%">
		            					Email:
		            				</th>
		            				<th style="width:12%">
		            					<input type="text" name="email" />
		            				</th>
		            				<th style="width:50%">
		            				</th>
		            			</tr>
		            		</table>
		            	</th>
		     	</tr>	
		        <tr>
		            	<th>
		            		<table>
		            			<tr>
		            				<th style="width:26%">
		            				</th>
		            				<th style="width:12%">
		            					Password:
		            				</th>
		            				<th style="width:12%"> 
		            					<input type="password" name="password" id="password"/>
		            				</th>
		            				<th style="width:50%">
		            				</th>
		            			</tr>
		            		</table>
		            	</th>
		     	</tr>	
		      	<tr>
		      		<th>
		      			  
		      		</th>
		      	</tr>
		      	<tr>
		            	<th>
		            		<br><input type="button" value="Login" onclick="formhash(this.form, this.form.password);" /> 
		            	</th>
		        	</form>
	        	</tr>
	 			<tr>
					<?php
		    		    if (login_check($mysqli) == true) {
		                	echo '<th><p>Currently logged ' . $logged . ' as ' . htmlentities($_SESSION['username']) . '.</p></th></tr>';
		 
				            echo '<tr><th><p>Do you want to change user? <a href="includes/logout.php">Log out</a></p></th>';
		        		} else {
		                 	echo '<th><p>Currently logged ' . $logged . '.</p></th></tr>';
		                 	echo "<tr><th><p>If you don't have a login, please <a href='register.php'>register</a></p></th>";
		                }
					?>
				</tr>
			</table>
		</div>     
    </body>
</html>