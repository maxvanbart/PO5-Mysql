<?php
//including the database connection file
include("includes/db_connect.php");
 
//getting id of the data from url
$id = $_GET['id'];
 
//deleting the row from table
$result = mysqli_query($mysqli, "DELETE FROM film WHERE id=$id");
$result1 = mysqli_query($mysqli, "DELETE FROM filmacteur WHERE filmnummer=$id");
$result2 = mysqli_query($mysqli, "DELETE FROM filmregisseur WHERE filmnummer=$id");
$result3 = mysqli_query($mysqli, "DELETE FROM filmgenre WHERE filmnummer=$id");
$result4 = mysqli_query($mysqli, "DELETE FROM filmwaarschuwing WHERE filmnummer=$id");
 
//redirecting to the display page (index.php in our case)
header("Location:gegevens.php");
?>
