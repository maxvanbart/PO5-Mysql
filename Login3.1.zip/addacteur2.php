<?php
include_once("includes/db_connect.php");
include_once 'includes/functions.php';
sec_session_start();
?>

<html>
<head>
    <title>Add Data</title>
    <link rel="stylesheet" href="css/login_screen.css" />
</head>
 
<body>
<?php if (login_check($mysqli) == true) : ?>
<div id='center_login' style="height: 10%;">
<?php
 
if(isset($_POST['Submit'])) {    
    $av = $_POST['acteurvoornaam'];
    $aa = $_POST['acteurachternaam'];
	
    // checking empty fields
    if(empty($av) || empty($aa)) {                
        if(empty($av)) {
            echo "<font color='red'>Voornaam Acteur field is empty.</font><br/>";
        }
        
        if(empty($aa)) {
            echo "<font color='red'>Achternaam Acteur field is empty.</font><br/>";
        }
        
        //link to the previous page
        echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
	} else { 
		
   		$controlle=mysqli_query($mysqli,"select * from acteur where acteurachternaam='$aa' and acteurvoornaam='$av'");
    	$controllerows=mysqli_num_rows($controlle);
		
		if($controllerows>0){
      		echo "Acteur exists";
   		} else {
   			
			$c = mysqli_query($mysqli, "INSERT INTO acteur(acteurvoornaam,acteurachternaam) VALUES('$av','$aa')");
	        
			echo "<font color='green'>".$av." ".$aa." is succesvol toegevoegd als acteur.";
   		}		
        echo "<br/><br><a href='gegevens.php'>View Result</a>";
    }
}
?>
</div>
<?php else : ?>
     <p>
         <span class="error">You are not authorized to access this page.</span> Please <a href="index.php">login</a>.
     </p>
<?php endif; ?>
</body>
</html>