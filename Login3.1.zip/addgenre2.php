<?php
include_once("includes/db_connect.php");
include_once 'includes/functions.php';
sec_session_start();
?>

<html>
<head>
    <title>Genre Toevoegen</title>
    <link rel="stylesheet" href="css/login_screen.css" />
</head>
 
<body>
<?php if (login_check($mysqli) == true) : ?>
<div id='center_login' style="height: 10%;">
<?php
 
if(isset($_POST['Submit'])) {    
    $genren = $_POST['genrenaam'];

    
    // checking empty fields
    if(empty($genren)) {                
        if(empty($genren)) {
            echo "<font color='red'>Genre field is empty.</font><br/>";
        }

	
        //link to the previous page
        echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
    } else { 
   		$controlle = mysqli_query($mysqli,"SELECT * FROM genre WHERE genrenaam='$genren'");		
    	$controllerows=mysqli_num_rows($controlle);

		if ($controllerows>0){
			echo "Genre exist";
   		} else {			
			$d = mysqli_query($mysqli, "INSERT INTO genre(genrenaam) VALUES('$genren')");
			$genre = $mysqli->insert_id;
			
	        echo "<font color='green'>Genre ".$genren." succesvol toegevoegd.";
   		}		
        echo "<br/><br><a href='gegevens.php'>View Result</a>";	
    }
}
?>
</div>
<?php else : ?>
     <p>
         <span class="error">You are not authorized to access this page.</span> Please <a href="index.php">login</a>.
     </p>
<?php endif; ?>
</body>
</html>