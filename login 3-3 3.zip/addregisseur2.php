<?php
include_once("includes/db_connect.php");
include_once 'includes/functions.php';
sec_session_start();
?>

<html>
<head>
    <title>Regisseur Toevoegen</title>
    <link rel="stylesheet" href="css/login_screen.css" />
</head>
 
<body>
<?php if (login_check($mysqli) == true) : ?>
<div id='center_login' style="height: 10%;">
<?php
 
if(isset($_POST['Submit'])) {    
    $rv = $_POST['regisseurvoornaam'];
    $ra = $_POST['regisseurachternaam'];
        
    // checking empty fields
    if(empty($rv) || empty($ra)) {                
        if(empty($rv)) {
            echo "<font color='red'>Voornaam Regisseur field is empty.</font><br/>";
        }
        
        if(empty($ra)) {
            echo "<font color='red'>Achternaam Regisseur field is empty.</font><br/>";
        }
		
        //link to the previous page
        echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
    } else { 
		      
		$controlle=mysqli_query($mysqli,"select * from regisseur where regisseurachternaam='$ra' and regisseurvoornaam='$rv'");
    	$controllerows=mysqli_num_rows($controlle);

		if($controllerows>0){
      		echo "Regisseur exists";
   		} else { 			
   			
        	$c = mysqli_query($mysqli, "INSERT INTO regisseur(regisseurvoornaam,regisseurachternaam) VALUES('$rv','$ra')");	
			
	        echo "<font color='green'>".$rv." ".$ra." is toegevoegd als regisseur.";
   		}		
        echo "<br/><br><a href='gegevens.php'>View Result</a>";	
    }
}
?>
</div>
<?php else : ?>
     <p>
         <span class="error">You are not authorized to access this page.</span> Please <a href="index.php">login</a>.
     </p>
<?php endif; ?>
</body>
</html>