<?php
// including the database connection file
include_once("includes/db_connect.php");
include_once 'includes/functions.php';
sec_session_start();
 
if(isset($_POST['update']))
{    
    $id = $_POST['id'];
    
    $titel=$_POST['titel'];
    $lc=$_POST['leeftijdscategorienummer'];
	$link=$_POST['imdblink'];
	$image = $_FILES['image']['name'];    
	$geweld = $_POST['geweld'];
	$angst = $_POST['angst'];
	$seks = $_POST['seks'];
	$grof = $_POST['grof'];
	$dralc = $_POST['dralc'];
	$discr = $_POST['discr'];
	$image = $_FILES['image']['name'];
	$foutl = 0;
	
	if ($lc < 5){
		if($seks == 1){
			echo"<font color='red'>Lekker neuken mag alleen voorkomen in films vanaf 16 jaar.</font><br/>";
			$foutl = 1;
		}
		if ($dralc == 1){
			echo"<font color='red'>Het gebruik van bier en andere lekker dingen mag alleen voorkomen in films vanaf 16 jaar.</font><br/>";
			$foutl = 1;
		}
	}
	
	if ($lc < 4){
		if ($grof == 1){
			echo"<font color='red'>Deadpool mag alleen voorkomen in films vanaf 12 jaar.</font><br/>";
			$foutl = 1;
		}
		if ($discr == 1){
			echo"<font color='red'>De witte superieuriteit mag alleen benadrukt worden in films vanaf 12 jaar.</font><br/>";
			$foutl = 1;
		}
	}
	
	if ($lc < 2){
		if ($angst == 1){
			echo"<font color='red'>Enge Spoken mogen alleen voorkomen in films vanaf 6.</font><br/>";
			$foutl = 1;
		}
		if ($geweld == 1){
			echo"<font color='red'>Dingen mogen alleen kapot geslagen worden in films vanaf 6.</font><br/>";
			$foutl = 1;
		}
	}
    
    // checking empty fields
    if(empty($titel) || empty($lc) || empty($link) || $foutl ==1 ) {            
        if(empty($titel)) {
            echo "<font color='red'>Titel field is empty.</font><br/>";
        }
   
        if(empty($lc)) {
            echo "<font color='red'>Leeftijdscategorienummer field is empty.</font><br/>";
        }
        if(empty($link)) {
            echo "<font color='red'>imdblink field is empty.</font><br/>";
        }            
    }


	else {    
        //updating the table
        $result = mysqli_query($mysqli, "UPDATE film SET titel = '$titel', leeftijdscategorienummer = '$lc', imdblink = '$link', image = '$image' WHERE id = ".$id);
		  	// image file directory
		  	$target = "covers/".basename($image);
	
		  	if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
		  		$msg = "Image uploaded successfully";
		  	}else{
		  		$msg = "Failed to upload image";
		  	}
        //redirectig to the display page. In our case, it is index.php
        header("Location: ../gegevens.php");
    }
}
?>
<?php
//getting id from url
$id = $_GET['id'];
 
//selecting data associated with this particular id
$result = mysqli_query($mysqli, "SELECT * FROM film WHERE id = $id");
 
while($res = mysqli_fetch_array($result))
{
    $titel = $res['titel'];
    $lc = $res['leeftijdscategorienummer'];
	$link = $res['imdblink'];
	$genren = $_POST['genrenaam'];
	$geweld = $_POST['geweld'];
	$angst = $_POST['angst'];
	$seks = $_POST['seks'];
	$grof = $_POST['grof'];
	$dralc = $_POST['dralc'];
	$discr = $_POST['discr']; 
	$image = $_FILES['image']['name'];
	
}
?>
<html>
<head>    
    <title>Film wijzigen</title>
    <link rel="stylesheet" type="text/css" href="css/login_screen.css" />
</head>
 
<body>
<?php if (login_check($mysqli) == true) : ?>
	<div id='center_login' style="height: 22%; width: 50%;">
    <a href="../gegevens.php">Home</a>
    <br/><br/>
	
    <form name="form1" method="post" action="filmedit.php" enctype="multipart/form-data">
        <table border="0">
            <tr> 
                <td>Titel</td>
                <td><input type="text" name="titel" value="<?php echo $titel;?>"></td>
            </tr>
			<tr>
				<td>Leeftijdscategorie</td>
				<td><input name="leeftijdscategorienummer" type="radio" value="1" <?php echo ($lc == '1') ? 'checked="checked"' : ''; ?>  >Alle leeftijden</td>
				<td><input name="leeftijdscategorienummer" type="radio" value="2" <?php echo ($lc == '2') ? 'checked="checked"' : ''; ?>  >Vanaf 6 jaar</td>
				<td><input name="leeftijdscategorienummer" type="radio" value="3" <?php echo ($lc == '3') ? 'checked="checked"' : ''; ?>  >Vanaf 9 jaar</td>
				<td><input name="leeftijdscategorienummer" type="radio" value="4" <?php echo ($lc == '4') ? 'checked="checked"' : ''; ?>  >Vanaf 12 jaar</td>
				<td><input name="leeftijdscategorienummer" type="radio" value="5" <?php echo ($lc == '5') ? 'checked="checked"' : ''; ?>  >Vanaf 16 jaar</td>
			</tr>
			<tr>
				<td>Waarschuwing</td>
				<input type="hidden" name="geweld" value=0>
				<td><input type="checkbox" name="geweld" value=1 <?php echo ($geweld == '1') ? 'checked="checked"' : ''; ?>>Geweld<br></td>
				
				
				
				<input type="hidden" name="angst" value=0>
				<td><input type="checkbox" name="angst" value=1 <?php echo ($angst == '1') ? 'checked="checked"' : ''; ?> >Angst<br></td>
				
				<input type="hidden" name="seks" value=0>
				<td><input type="checkbox" name="seks" value=1 <?php echo ($seks == '1') ? 'checked="checked"' : ''; ?>>Seks<br></td>
				
				<input type="hidden" name="grof" value=0>
				<td><input type="checkbox" name="grof" value=1 <?php echo ($grof == '1') ? 'checked="checked"' : ''; ?>>Grof<br></td>
				<input type="hidden" name="dralc" value=0>
				<td><input type="checkbox" name="dralc" value=1 <?php echo ($dralc == '1') ? 'checked="checked"' : ''; ?>>Drugs- en/of alcoholgebruik<br></td>
				<input type="hidden" name="discr" value=0>
				<td><input type="checkbox" name="discr" value=1 <?php echo ($discr == '1') ? 'checked="checked"' : ''; ?> >Discriminatie<br></td>
				
            </tr>
            <tr> 
                <td>imdblink</td>
                <td><input type="text" name="imdblink" value="<?php echo $link;?>"></td>
            </tr>
			<tr>
				  <td><input type="file" name="image" enctype="multipart/form-data"></td>
		  	</tr>
            <tr>
                <td><input type="hidden" name="id" value=<?php echo $_GET['id'];?>></td>
                <td><input type="submit" name="update" value="Update"></td>
            </tr>
        </table>
    </form>
    </div>
<?php else : ?>
     <p>
         <span class="error">You are not authorized to access this page.</span> Please <a href="index.php">login</a>.
     </p>
<?php endif; ?>
</body>
</html>